
document.addEventListener("DOMContentLoaded", () => {
  const user = JSON.parse(localStorage.getItem("loggedInUser"));

  const loginLink = document.getElementById("login-link");
  const logoutLink = document.getElementById("logout-link");
  const navUser = document.getElementById("nav-user");

  if (user) {
   
    if (loginLink) loginLink.style.display = "none";

  
    if (navUser) {
      navUser.innerText = "Hi, " + user.name;
      navUser.style.marginRight = "12px";
      navUser.style.fontWeight = "600";
      navUser.style.color = "#b71c1c";
    }

    
    if (logoutLink) logoutLink.style.display = "inline-block";
  }
});


function logout() {
  localStorage.removeItem("loggedInUser");
  alert("Logged out successfully");
  window.location.href = "index.html";
}
