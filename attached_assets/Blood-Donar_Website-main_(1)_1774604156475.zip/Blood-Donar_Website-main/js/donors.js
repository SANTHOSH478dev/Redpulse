function showDonors(){
let blood=document.getElementById("searchBlood").value;
let donors=JSON.parse(localStorage.getItem("donors"))||[];
let result=document.getElementById("result");
result.innerHTML="";
donors.filter(d=>d.blood===blood).forEach(d=>{
result.innerHTML+=`<div class='card'><h3>${d.name}</h3><p>${d.city}</p><p>${d.phone}</p></div>`;
});}