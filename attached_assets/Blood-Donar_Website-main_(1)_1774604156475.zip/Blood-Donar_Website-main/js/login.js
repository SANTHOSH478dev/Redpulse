function loginUser() {
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;


  let donors = JSON.parse(localStorage.getItem("donors")) || [];


  const user = donors.find((d) => d.email === email && d.password === password);

  if (!user) {
    alert("Invalid email or password!");
    return false;
  }


  localStorage.setItem("loggedInUser", JSON.stringify(user));

  alert("Login successful! Welcome " + user.name);
  window.location.href = "index.html";
  return false;
}
