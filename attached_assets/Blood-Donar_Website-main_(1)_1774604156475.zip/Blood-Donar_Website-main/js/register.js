function saveDonor() {
  const name = document.getElementById("name").value.trim();
  const age = parseInt(document.getElementById("age").value);
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;
  const confirmPassword = document.getElementById("confirmPassword").value;
  const blood = document.getElementById("blood").value;
  const city = document.getElementById("city").value.trim();
  const phone = document.getElementById("phone").value.trim();

  if (password !== confirmPassword) {
    alert("Passwords do not match!");
    return false;
  }

  let donors = JSON.parse(localStorage.getItem("donors")) || [];

  if (donors.find((d) => d.email === email)) {
    alert("Email already registered. Please login.");
    window.location.href = "login.html";
    return false;
  }

  donors.push({
    name,
    age,
    email,
    password,
    blood,
    city,
    phone,
    status: "Available",
  });

  localStorage.setItem("donors", JSON.stringify(donors));

  alert("Registration successful! Please login.");
  window.location.href = "login.html";
  return false;
}
