
const loggedUser = localStorage.getItem("loggedUser");
if (!loggedUser) {
  alert("Please login to donate blood");
  window.location.href = "login.html";
}


const donors = JSON.parse(localStorage.getItem("donors")) || [];
const donor = donors.find((d) => d.email === loggedUser);

if (!donor) {
  alert("Donor profile not found");
  window.location.href = "login.html";
}


document.getElementById("name").value = donor.name;
document.getElementById("email").value = donor.email;
document.getElementById("blood").value = donor.blood;
document.getElementById("phone").value = donor.phone;


function submitAppointment() {
  const appointment = {
    id: Date.now(),
    name: donor.name,
    email: donor.email,
    blood: donor.blood,
    phone: donor.phone,
    date: document.getElementById("date").value,
    time: document.getElementById("time").value,
    center: document.getElementById("center").value,
    notes: document.getElementById("notes").value,
    status: "Under Review", 
  };

  let appointments = JSON.parse(localStorage.getItem("appointments")) || [];

  appointments.push(appointment);

  localStorage.setItem("appointments", JSON.stringify(appointments));
  localStorage.setItem("currentAppointment", JSON.stringify(appointment));


  setTimeout(() => approveAppointment(appointment.id), 10000); 

  window.location.href = "appointment-success.html";
  return false;
}


function approveAppointment(id) {
  let appointments = JSON.parse(localStorage.getItem("appointments")) || [];

  appointments = appointments.map((a) => {
    if (a.id === id) {
      a.status = "Approved"; 
    }
    return a;
  });

  localStorage.setItem("appointments", JSON.stringify(appointments));
}
